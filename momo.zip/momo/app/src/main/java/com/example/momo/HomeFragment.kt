package com.example.momo

import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

}
